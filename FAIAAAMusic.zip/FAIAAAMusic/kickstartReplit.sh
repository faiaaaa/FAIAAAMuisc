echo Kickstarting replit
echo Please make sure to fill config.js before running this script
npm i
npm run deploy
node index.js
